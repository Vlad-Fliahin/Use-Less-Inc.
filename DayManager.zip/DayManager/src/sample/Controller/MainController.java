package sample.Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MainController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button shedulebutton;

    @FXML
    private Button calendarbutton;

//    @FXML
//    private Button helpButton;

    @FXML
    private Button aboutButton;

    @FXML
    void initialize() {
        shedulebutton.setOnAction(event -> {
            Stage stg = (Stage) shedulebutton.getScene().getWindow();
            // do what you have to do
            stg.hide();
            stg.setTitle("Day Manager");

//            FXMLLoader loader = new FXMLLoader();
//            loader.setLocation(getClass().getResource("/sample/FXML/ScheduleWindow.fxml"));
////            loader.setRoot(loader.getClass().getResource("/sample/FXML/ScheduleWindow.fxml"));
//
//            try {
//                loader.load();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//
//            Parent root = loader.getRoot();
//            Stage stage = new Stage();
//            stage.setTitle("Day Manager");
//            stage.setScene(new Scene(root));
//            stage.show();

            try {
                Schedule sc = new Schedule();
                sc.start(stg);
            } catch (Exception e) {
                e.printStackTrace();
            }

        });

        calendarbutton.setOnAction(event -> {
            Stage stg = (Stage) calendarbutton.getScene().getWindow();
            // do what you have to do
            stg.hide();
            stg.setTitle("Day Manager");

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/FXML/CalendarWindow.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setTitle("Day Manager");
            stage.setScene(new Scene(root));
            stage.show();
        });

//        helpButton.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent actionEvent) {
//                Stage stage = (Stage) helpButton.getScene().getWindow();
//                stage.hide();
//                stage.setTitle("Day Manager");
//
//                FXMLLoader loader = new FXMLLoader();
//                loader.setLocation(getClass().getResource("/sample/FXML/Help.fxml"));
//
//                try {
//                    loader.load();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//
//                Parent root = loader.getRoot();
//                stage.setScene(new Scene(root));
//                stage.show();
//            }
//        });

        aboutButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Stage stage = (Stage) aboutButton.getScene().getWindow();
                stage.hide();
                stage.setTitle("Day Manager");

                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/FXML/About.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                stage.setScene(new Scene(root));
                stage.show();
            }
        });
    }
}
