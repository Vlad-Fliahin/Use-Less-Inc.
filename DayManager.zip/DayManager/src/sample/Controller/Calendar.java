package sample.Controller;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import static java.lang.Integer.parseInt;

public class Calendar {

    @FXML
    private Button exitButton;

    @FXML
    private DatePicker datePicker;

    @FXML
    private Button addButton;

    @FXML
    private TextArea resultText;

    @FXML
    private Button showButton;

    @FXML
    private TextArea noteText;

    @FXML
    private Button deleteButton;

    @FXML
    void initialize() throws IOException {
        NoteData nd = new NoteData();

        resultText.setText(nd.getTodayDate());

        exitButton.setOnAction(event -> {
            Stage stg = (Stage) exitButton.getScene().getWindow();
//            // do what you have to do
            stg.hide();
            stg.setTitle("Day Manager");

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/FXML/MainWindow.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setTitle("Day Manager");
            stage.setScene(new Scene(root));
            stage.show();
        });

        addButton.setOnAction(new EventHandler<javafx.event.ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                try {
                    nd.setData(datePicker.getValue().getYear(), datePicker.getValue().getMonthValue(), datePicker.getValue().getDayOfMonth(), noteText.getText());
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

                noteText.setText("");
            }
        });

        showButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                resultText.setText(nd.getData(datePicker.getValue().getYear(), datePicker.getValue().getMonthValue(), datePicker.getValue().getDayOfMonth()));
            }
        });

        deleteButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    nd.deleteData(datePicker.getValue().getYear(), datePicker.getValue().getMonthValue(), datePicker.getValue().getDayOfMonth());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public class NoteData {
        private final int MaxYear = 10000, MaxMonth = 15, MaxDay = 35;
        private String [][][] data = new String[MaxYear][MaxMonth][MaxDay];
        private int yearNow, monthNow, dayNow;

        NoteData() throws IOException {
            Date date = new Date();
            LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            this.yearNow = localDate.getYear();
            this.monthNow = localDate.getMonthValue();
            this.dayNow = localDate.getDayOfMonth();

            for (int i = 0; i < MaxYear; ++i) {
                for (int j = 0; j < MaxMonth; ++j) {
                    for (int k = 0; k < MaxDay; ++k) {
                        data[i][j][k] = "";
                    }
                }
            }
            readFromFile();
        }

        public void saveToFile () throws IOException {
            FileWriter fw = new FileWriter("Info.txt");

            for (int i = 0; i < MaxYear; ++i) {
                for (int j = 0; j < MaxMonth; ++j) {
                    for (int k = 0; k < MaxDay; ++k) {
                        if(data[i][j][k] != "") {
                            fw.write(i + "/" + j + "/" + k + "/" + data[i][j][k] + "\n");
                        }
                    }
                }
            }
            fw.close();
        }

        public void readFromFile() throws IOException {
            FileReader fr = new FileReader("Info.txt");
            Scanner sc = new Scanner(fr);

            while (sc.hasNextLine()) {
                String info = sc.nextLine();

                if (info.equals("")) {
                    continue;
                }

                int id = 0;
                String s = "";
                String pData [] = new String[10];

                System.out.println(info);

                for (int i = 0; i < info.length(); ++i) {
                    if (info.charAt(i) == '/') {
                        pData[id] = s;
                        s = "";
                        ++id;
                    } else if(info.charAt(i) == '\u2063') {
                        s += "\n";
                    } else {
                        s += info.charAt(i);
                    }
                }

                pData[3] = s;

                System.out.println(pData[0]);
                System.out.println(pData[1]);
                System.out.println(pData[2]);
                System.out.println(pData[3]);

                data[Integer.parseInt(pData[0])][Integer.parseInt(pData[1])]
                        [Integer.parseInt(pData[2])] = pData[3];
            }
        }

        public void setData(int year, int month, int day, String text) throws IOException {
            data[year][month][day] += text + "\u2063";
            saveToFile();
        }

        public String getData(int year, int month, int day) {
            String res = "", s = data[year][month][day];

            for (int i = 0; i < s.length(); ++i) {
                if(s.charAt(i) == '\u2063') {
                    res += "\n";
                } else {
                    res += s.charAt(i);
                }
            }

            return res;
        }

        public void deleteData(int year, int month, int day) throws IOException {
            data[year][month][day] = "";
            saveToFile();
        }

        public String getTodayDate() {
            return getData(yearNow, monthNow, dayNow);
        }
    }
}
