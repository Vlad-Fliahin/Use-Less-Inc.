package sample.Controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;

public class Help {

    private String text = "Для добавления введите нужный текст в соответствующую ячейку и нажмите Enter.\n" +
            "Для добавления напоминания выберите нужный день в календаре и введите напоминание. Нажмите \"Добавить\".\n" +
            "По умолчанию во втором поле отображаются напоминания на сегодня.\n" +
            "Чтобы просмотреть напоминания на другую дату, выберите ее в календаре и нажмите \"Узнать планы на дату\".\n" +
            "Кнопка \"Удалить планы на дату\" удаляет все планы на выбранный день.";

    @FXML
    private Button exitButton;

    @FXML
    private TextArea helpText;

    @FXML
    void initialize() {
        helpText.setText(text);

        exitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Stage stage = (Stage) exitButton.getScene().getWindow();
                stage.hide();

                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/FXML/MainWindow.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                stage.setTitle("Day Manager");
                stage.setScene(new Scene(root));
                stage.show();
            }


        });
    }
}