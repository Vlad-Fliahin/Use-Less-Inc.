package sample.Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

public class sController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<Week> tablenure;

    @FXML
    private TableColumn<Week, String> mondayColumn;

    @FXML
    private TableColumn<Week, String> tuesdayColumn;

    @FXML
    private TableColumn<Week, String> wednesdayColumn;

    @FXML
    private TableColumn<Week, String> thursdayColumn;

    @FXML
    private TableColumn<Week, String> fridayColumn;

    @FXML
    private TableColumn<Week, String> saturdayColumn;

    @FXML
    private TableColumn<Week, String> sundayColumn;

    @FXML
    private Button exitButton;

    @FXML
    private TextField mondayText;

    @FXML
    private TextField tuesdayText;

    @FXML
    private TextField wednesdayText;

    @FXML
    private TextField thursdayText;

    @FXML
    private TextField fridayText;

    @FXML
    private TextField saturdayText;

    @FXML
    private TextField sundayText;

    @FXML
    private Button addButton;

    @FXML
    void initialize() {
        final ObservableList<Week> data =
                FXCollections.observableArrayList(
                        new Week("Math", "OPI", "", "", "English", "", ""),
                        new Week("BGD", "Math", "CDM", "English", "PT", "", "Algorithms"));

        mondayColumn.setCellValueFactory(new PropertyValueFactory <Week, String> ("monday"));
        mondayColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        mondayColumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Week, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Week, String> t) {
                    ((Week) t.getTableView().getItems().get(
                            t.getTablePosition().getRow())
                    ).setMonday(t.getNewValue());
                }
        });

        tuesdayColumn.setCellValueFactory(new PropertyValueFactory <Week, String> ("tuesday"));
        tuesdayColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        tuesdayColumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Week, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Week, String> t) {
                ((Week) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                ).setTuesday(t.getNewValue());
            }
        });

        wednesdayColumn.setCellValueFactory(new PropertyValueFactory <Week, String> ("wednesday"));
        wednesdayColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        wednesdayColumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Week, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Week, String> t) {
                ((Week) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                ).setWednesday(t.getNewValue());
            }
        });

        thursdayColumn.setCellValueFactory(new PropertyValueFactory <Week, String> ("thursday"));
        thursdayColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        thursdayColumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Week, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Week, String> t) {
                ((Week) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                ).setThursday(t.getNewValue());
            }
        });

        fridayColumn.setCellValueFactory(new PropertyValueFactory <Week, String> ("friday"));
        fridayColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        fridayColumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Week, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Week, String> t) {
                ((Week) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                ).setFriday(t.getNewValue());
            }
        });

        saturdayColumn.setCellValueFactory(new PropertyValueFactory <Week, String> ("saturday"));
        saturdayColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        saturdayColumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Week, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Week, String> t) {
                ((Week) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                ).setSaturday(t.getNewValue());
            }
        });

        sundayColumn.setCellValueFactory(new PropertyValueFactory <Week, String> ("sunday"));
        sundayColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        sundayColumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<Week, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Week, String> t) {
                ((Week) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                ).setSunday(t.getNewValue());
            }
        });

        tablenure.setItems(data);
        tablenure.getColumns().addAll(mondayColumn, tuesdayColumn, wednesdayColumn, thursdayColumn, fridayColumn, saturdayColumn, sundayColumn);

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                data.add(new Week(
                        mondayText.getText(),
                        tuesdayText.getText(),
                        wednesdayText.getText(),
                        thursdayText.getText(),
                        fridayText.getText(),
                        saturdayText.getText(),
                        sundayText.getText()));
                mondayText.clear();
                tuesdayText.clear();
                wednesdayText.clear();
                thursdayText.clear();
                fridayText.clear();
                saturdayText.clear();
                sundayText.clear();
            }
        });

        exitButton.setOnAction(event -> {
            Stage stg = (Stage) exitButton.getScene().getWindow();
//            // do what you have to do
            stg.hide();
            stg.setTitle("Day Manager");

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/FXML/MainWindow.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }

    public static class Week {
        private String monday, tuesday, wednesday, thursday, friday, saturday, sunday;

        public Week(String monday, String tuesday, String wednesday, String thursday, String friday, String saturday, String sunday) {
            this.monday = monday;
            this.tuesday = tuesday;
            this.wednesday = wednesday;
            this.thursday = thursday;
            this.friday = friday;
            this.saturday = saturday;
            this.sunday = sunday;
        }

        public String getMonday() {
            return monday;
        }

        public void setMonday(String monday) {
            this.monday = monday;
        }

        public String getTuesday() {
            return tuesday;
        }

        public void setTuesday(String tuesday) {
            this.tuesday = tuesday;
        }

        public String getWednesday() {
            return wednesday;
        }

        public void setWednesday(String wednesday) {
            this.wednesday = wednesday;
        }

        public String getThursday() {
            return thursday;
        }

        public void setThursday(String thursday) {
            this.thursday = thursday;
        }

        public String getFriday() {
            return friday;
        }

        public void setFriday(String friday) {
            this.friday = friday;
        }

        public String getSaturday() {
            return saturday;
        }

        public void setSaturday(String saturday) {
            this.saturday = saturday;
        }

        public String getSunday() {
            return sunday;
        }

        public void setSunday(String sunday) {
            this.sunday = sunday;
        }
    }
}
