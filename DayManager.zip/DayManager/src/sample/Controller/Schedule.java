package sample.Controller;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Schedule extends Application {

    Table tableClass;

    {
        try {
            tableClass = new Table();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private TableView<Week> table = new TableView<Week>();
    private final ObservableList<Week> data =
            FXCollections.observableArrayList(
                    new Week(tableClass.tableDate[0][0], tableClass.tableDate[0][1], tableClass.tableDate[0][2], tableClass.tableDate[0][3],
                            tableClass.tableDate[0][4], tableClass.tableDate[0][5], tableClass.tableDate[0][6]),
                    new Week(tableClass.tableDate[1][0], tableClass.tableDate[1][1], tableClass.tableDate[1][2], tableClass.tableDate[1][3],
                            tableClass.tableDate[1][4], tableClass.tableDate[1][5], tableClass.tableDate[1][6]),
                    new Week(tableClass.tableDate[2][0], tableClass.tableDate[2][1], tableClass.tableDate[2][2], tableClass.tableDate[2][3],
                            tableClass.tableDate[2][4], tableClass.tableDate[2][5], tableClass.tableDate[2][6]),
                    new Week(tableClass.tableDate[3][0], tableClass.tableDate[3][1], tableClass.tableDate[3][2], tableClass.tableDate[3][3],
                            tableClass.tableDate[3][4], tableClass.tableDate[3][5], tableClass.tableDate[3][6]),
                    new Week(tableClass.tableDate[4][0], tableClass.tableDate[4][1], tableClass.tableDate[4][2], tableClass.tableDate[4][3],
                            tableClass.tableDate[4][4], tableClass.tableDate[4][5], tableClass.tableDate[4][6]),
                    new Week(tableClass.tableDate[5][0], tableClass.tableDate[5][1], tableClass.tableDate[5][2], tableClass.tableDate[5][3],
                            tableClass.tableDate[5][4], tableClass.tableDate[5][5], tableClass.tableDate[5][6]),
                    new Week(tableClass.tableDate[6][0], tableClass.tableDate[6][1], tableClass.tableDate[6][2], tableClass.tableDate[6][3],
                            tableClass.tableDate[6][4], tableClass.tableDate[6][5], tableClass.tableDate[6][6]));
    final HBox hb = new HBox();
    final HBox hbexit = new HBox();
    final HBox hblabel = new HBox();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        Scene scene = new Scene(new Group());
        stage.setTitle("Day Manager");
        stage.setWidth(800);
        stage.setHeight(625);

        final Label label = new Label("Расписание ХНУРЭ");
        final Label l1 = new Label("");
        final Label l2 = new Label("");
        label.setFont(new Font("American Typewriter", 20));

        Region region1 = new Region();
        HBox.setHgrow(region1, Priority.ALWAYS);

        Region region2 = new Region();
        HBox.setHgrow(region2, Priority.ALWAYS);

        hblabel.getChildren().addAll(l1, region1, label, region2, l2);
        table.setEditable(true);

        TableColumn mondaycolumn = new TableColumn("Понедельник");
        mondaycolumn.setMinWidth(110);
        mondaycolumn.setCellValueFactory(
                new PropertyValueFactory<Week, String>("Monday"));
        mondaycolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        mondaycolumn.setOnEditCommit(
                new EventHandler<CellEditEvent<Week, String>>() {
                    @Override
                    public void handle(CellEditEvent<Week, String> t) {
                        ((Week) t.getTableView().getItems().get(
                                t.getTablePosition().getRow())
                        ).setMonday(t.getNewValue());

                        try {
                            tableClass.setTableDate(t.getTablePosition().getRow(), 0, t.getNewValue());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        TableColumn tuesdaycolumn = new TableColumn("Вторник");
        tuesdaycolumn.setMinWidth(100);
        tuesdaycolumn.setCellValueFactory(
                new PropertyValueFactory<Week, String>("Tuesday"));
        tuesdaycolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        tuesdaycolumn.setOnEditCommit(
                new EventHandler<CellEditEvent<Week, String>>() {
                    @Override
                    public void handle(CellEditEvent<Week, String> t) {
                        ((Week) t.getTableView().getItems().get(
                                t.getTablePosition().getRow())
                        ).setTuesday(t.getNewValue());

                        try {
                            tableClass.setTableDate(t.getTablePosition().getRow(), 1, t.getNewValue());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        TableColumn wednesdaycolumn = new TableColumn("Среда");
        wednesdaycolumn.setMinWidth(110);
        wednesdaycolumn.setCellValueFactory(
                new PropertyValueFactory<Week, String>("Wednesday"));
        wednesdaycolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        wednesdaycolumn.setOnEditCommit(
                new EventHandler<CellEditEvent<Week, String>>() {
                    @Override
                    public void handle(CellEditEvent<Week, String> t) {
                        ((Week) t.getTableView().getItems().get(
                                t.getTablePosition().getRow())
                        ).setWednesday(t.getNewValue());

                        try {
                            tableClass.setTableDate(t.getTablePosition().getRow(), 2, t.getNewValue());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        TableColumn thursdaycolumn = new TableColumn("Четверг");
        thursdaycolumn.setMinWidth(110);
        thursdaycolumn.setCellValueFactory(
                new PropertyValueFactory<Week, String>("Thursday"));
        thursdaycolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        thursdaycolumn.setOnEditCommit(
                new EventHandler<CellEditEvent<Week, String>>() {
                    @Override
                    public void handle(CellEditEvent<Week, String> t) {
                        ((Week) t.getTableView().getItems().get(
                                t.getTablePosition().getRow())
                        ).setThursday(t.getNewValue());

                        try {
                            tableClass.setTableDate(t.getTablePosition().getRow(), 3, t.getNewValue());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        TableColumn fridaycolumn = new TableColumn("Пятница");
        fridaycolumn.setMinWidth(110);
        fridaycolumn.setCellValueFactory(
                new PropertyValueFactory<Week, String>("Friday"));
        fridaycolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        fridaycolumn.setOnEditCommit(
                new EventHandler<CellEditEvent<Week, String>>() {
                    @Override
                    public void handle(CellEditEvent<Week, String> t) {
                        ((Week) t.getTableView().getItems().get(
                                t.getTablePosition().getRow())
                        ).setFriday(t.getNewValue());

                        try {
                            tableClass.setTableDate(t.getTablePosition().getRow(), 4, t.getNewValue());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        TableColumn saturdaycolumn = new TableColumn("Суббота");
        saturdaycolumn.setMinWidth(110);
        saturdaycolumn.setCellValueFactory(
                new PropertyValueFactory<Week, String>("Saturday"));
        saturdaycolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        saturdaycolumn.setOnEditCommit(
                new EventHandler<CellEditEvent<Week, String>>() {
                    @Override
                    public void handle(CellEditEvent<Week, String> t) {
                        ((Week) t.getTableView().getItems().get(
                                t.getTablePosition().getRow())
                        ).setSaturday(t.getNewValue());

                        try {
                            tableClass.setTableDate(t.getTablePosition().getRow(), 5, t.getNewValue());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        TableColumn sundaycolumn = new TableColumn("Воскресенье");
        sundaycolumn.setMinWidth(110);
        sundaycolumn.setCellValueFactory(
                new PropertyValueFactory<Week, String>("Sunday"));
        sundaycolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        sundaycolumn.setOnEditCommit(
                new EventHandler<CellEditEvent<Week, String>>() {
                    @Override
                    public void handle(CellEditEvent<Week, String> t) {
                        ((Week) t.getTableView().getItems().get(
                                t.getTablePosition().getRow())
                        ).setSunday(t.getNewValue());

                        try {
                            tableClass.setTableDate(t.getTablePosition().getRow(), 6, t.getNewValue());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );

        table.setItems(data);
        table.getColumns().addAll(mondaycolumn, tuesdaycolumn, wednesdaycolumn, thursdaycolumn, fridaycolumn, saturdaycolumn, sundaycolumn);

        final Button exitButton = new Button("Вернуться в меню");
        exitButton.setDefaultButton(true);
        exitButton.setOnAction(event -> {
            Stage stg = (Stage) exitButton.getScene().getWindow();
//            // do what you have to do
            stg.hide();
            stg.setTitle("Day Manager");

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/FXML/MainWindow.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            stage.setScene(new Scene(root));
            stage.show();
        });

        Region region = new Region();
        hbexit.setHgrow(region, Priority.ALWAYS);

        hbexit.getChildren().addAll(region, exitButton);
        hbexit.setSpacing(5);

        final VBox vbox = new VBox();
        vbox.setSpacing(20);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(hblabel, table, hb, hbexit);

        ((Group) scene.getRoot()).getChildren().addAll(vbox);

        stage.setScene(scene);
        stage.show();
    }

    public static class Week {
        private String monday, tuesday, wednesday, thursday, friday, saturday, sunday;

        public Week(String monday, String tuesday, String wednesday, String thursday, String friday, String saturday, String sunday) {
            this.monday = monday;
            this.tuesday = tuesday;
            this.wednesday = wednesday;
            this.thursday = thursday;
            this.friday = friday;
            this.saturday = saturday;
            this.sunday = sunday;
        }

        public String getMonday() {
            return monday;
        }

        public void setMonday(String monday) {
            this.monday = monday;
        }

        public String getTuesday() {
            return tuesday;
        }

        public void setTuesday(String tuesday) {
            this.tuesday = tuesday;
        }

        public String getWednesday() {
            return wednesday;
        }

        public void setWednesday(String wednesday) {
            this.wednesday = wednesday;
        }

        public String getThursday() {
            return thursday;
        }

        public void setThursday(String thursday) {
            this.thursday = thursday;
        }

        public String getFriday() {
            return friday;
        }

        public void setFriday(String friday) {
            this.friday = friday;
        }

        public String getSaturday() {
            return saturday;
        }

        public void setSaturday(String saturday) {
            this.saturday = saturday;
        }

        public String getSunday() {
            return sunday;
        }

        public void setSunday(String sunday) {
            this.sunday = sunday;
        }
    }

    public static class Table {
        private int dayInWeek = 7, classCount = 6;
        private String tableDate [][] = new String[10][10];

        Table() throws IOException {
            for (int i = 0; i < classCount; ++i) {
                for (int j = 0; j < dayInWeek; ++j) {
                    tableDate[i][j] = "";
                }
            }

            readFromFile();
        }

        public void setTableDate(int row, int column, String val) throws IOException {
            tableDate[row][column] = val;
            saveToFile();
        }

        public void saveToFile() throws IOException {
            FileWriter fw = new FileWriter("Schedule.txt");

            for (int i = 0; i < classCount; ++i) {
                for (int j = 0; j < dayInWeek; ++j) {
                    fw.write(tableDate[i][j] + "/");
                }
                fw.write("\n");
            }

            fw.close();
        }

        public void readFromFile() throws IOException {
            FileReader fr = new FileReader("Schedule.txt");
            Scanner sc = new Scanner(fr);

            int counter = 0;
            while (sc.hasNextLine()) {
                String info = sc.nextLine();

                if (info.equals("")) {
                    continue;
                }

                int id = 0;
                String s = "";
                String pData [] = new String[dayInWeek + 3];

//                System.out.println(info);

                for (int i = 0; i < info.length(); ++i) {
                    if (info.charAt(i) == '/') {
                        pData[id] = s;
                        s = "";
                        ++id;
                    } else {
                        s += info.charAt(i);
                    }
                }

                pData[id] = s;

//                System.out.println(pData[0]);
//                System.out.println(pData[1]);
//                System.out.println(pData[2]);
//                System.out.println(pData[3]);
//                System.out.println(pData[4]);
//                System.out.println(pData[5]);
//                System.out.println(pData[6]);

//                for (int i = 0; i < id; ++i) {
//                    System.out.print(pData[i] + "! ");
//                }
//                System.out.println();

                for (int i = 0; i < dayInWeek; ++i) {
                    tableDate[counter][i] = pData[i];
                }

                ++counter;
            }

//            for (int i = 0; i < classCount; ++i) {
//                for (int j = 0; j < dayInWeek; ++j) {
//                    System.out.print(tableDate[i][j] + "! ");
//                }
//                System.out.println();
//            }
        }
    }
}