package sample.Controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;

public class About {

    private String text = "Manager: 050 973 44 32 \nTechnical Support: 050 054 18 40 \nemail: uselessinc@gmail.com";

    @FXML
    private Button exitButton;

    @FXML
    private TextArea helpText;

    @FXML
    void initialize() {
        helpText.setText(text);

        exitButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Stage stage = (Stage) exitButton.getScene().getWindow();
                stage.hide();

                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/FXML/MainWindow.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                stage.setTitle("Day Manager");
                stage.setScene(new Scene(root));
                stage.show();
            }
        });
    }
}